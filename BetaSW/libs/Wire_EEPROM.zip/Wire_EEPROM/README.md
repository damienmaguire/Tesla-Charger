Wire_EEPROM
===========

I2C based routines to support EEPROM on the Due. Requires the due_wire library from my repo
