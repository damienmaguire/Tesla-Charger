can_common
=======

A set of shared structures, classes, and functionality that multiple CAN libraries
might need. Created to unify the due_can and mcp2515 libraries on the Due such that
both can be used interchangeably. This library isn't solely responsible for this
but does include CAN frame structures and other common functionality.
